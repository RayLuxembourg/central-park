import { animation, query, style, stagger, animate } from '@angular/animations';

export default (element, stag) =>
  animation([
    query(
      element,
      [
        style({ transform: 'translateX({{distance}})', opacity: 0 }),
        stagger(stag, [animate('{{timing}}', style('*'))])
      ],
      { optional: true }
    )
  ]);
