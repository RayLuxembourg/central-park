export interface Ranger {
  id: number;
  name: string;
  counter: number;
  reports: number;
  image: string;
}
